import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

const bg = Color(0xFF070910);
const panel = Color(0xFF111827);
const purple = Color(0xFF8B3DFF);
const cyan = Color(0xFF00C8FF);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RapIuzyClipperApp());
}

class RapIuzyClipperApp extends StatelessWidget {
  const RapIuzyClipperApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'RAPIUZY AI Clipper',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: purple, secondary: cyan, surface: panel),
      snackBarTheme: const SnackBarThemeData(backgroundColor: panel),
    ),
    home: const SplashScreen(),
  );
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))..repeat(reverse: true);
  @override void initState() { super.initState(); Timer(const Duration(milliseconds: 2200), () { if (mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const ClipperHome())); }); }
  @override void dispose() { pulse.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(body: Container(
    decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment(0, -.2), radius: 1.05, colors: [Color(0xFF1A1641), bg])),
    child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      AnimatedBuilder(animation: pulse, builder: (_, child) => Transform.scale(scale: .96 + pulse.value * .05, child: child), child: ClipRRect(borderRadius: BorderRadius.circular(28), child: Image.asset('assets/images/app_icon.png', width: 138, height: 138, fit: BoxFit.cover))),
      const SizedBox(height: 24), const Text('RAPIUZY AI', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
      const SizedBox(height: 5), const Text('CLIPPER  •  by RAPIUZY', style: TextStyle(color: Color(0xFFB7B7D8), letterSpacing: 2, fontSize: 12)),
      const SizedBox(height: 30), const SizedBox(width: 160, child: LinearProgressIndicator(minHeight: 4, borderRadius: BorderRadius.all(Radius.circular(99)), color: cyan, backgroundColor: Color(0x332D2D50))),
      const SizedBox(height: 12), const Text('Menyiapkan studio klip…', style: TextStyle(color: Colors.white60, fontSize: 12)),
    ])),
  ));
}

class ClipperHome extends StatefulWidget { const ClipperHome({super.key}); @override State<ClipperHome> createState() => _ClipperHomeState(); }
class _ClipperHomeState extends State<ClipperHome> {
  String? videoPath; String? videoName; bool busy = false;
  Future<void> pickVideo() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.video, allowMultiple: false, withData: false);
      if (result == null || result.files.isEmpty) return;
      final file = result.files.single;
      if (file.path == null) { showMsg('File tidak bisa dibaca. Coba pilih video dari penyimpanan perangkat.'); return; }
      setState(() { videoPath = file.path; videoName = file.name; });
    } catch (_) { showMsg('Gagal membuka video. Coba lagi.'); }
  }
  void showMsg(String text) { if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text))); }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: bg, titleSpacing: 18, title: Row(children: [Container(width: 35, height: 35, clipBehavior: Clip.antiAlias, decoration: BoxDecoration(borderRadius: BorderRadius.circular(10)), child: Image.asset('assets/images/app_icon.png', fit: BoxFit.cover)), const SizedBox(width: 10), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('RAPIUZY AI', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)), Text('CLIPPER STUDIO', style: TextStyle(fontSize: 9, color: cyan, letterSpacing: 1.8))])]), actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'RAPIUZY AI Clipper', applicationVersion: '1.0.0', children: const [Text('Studio untuk menyiapkan video pendek. Pemrosesan AI otomatis perlu dihubungkan ke backend clipping.')]), icon: const Icon(Icons.info_outline))]),
    body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(18, 10, 18, 28), children: [
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF1C1850), Color(0xFF101729), Color(0xFF10121C)]), border: Border.all(color: const Color(0x553D66FF))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('UBAH VIDEO PANJANG', style: TextStyle(fontSize: 11, color: cyan, fontWeight: FontWeight.w800, letterSpacing: 1.8)), const SizedBox(height: 8), const Text('Jadi klip yang\nsiap diposting.', style: TextStyle(fontSize: 27, height: 1.1, fontWeight: FontWeight.w900)), const SizedBox(height: 10), const Text('Pilih video, atur rasio, dan siapkan gaya subtitle.', style: TextStyle(color: Colors.white70, height: 1.45)), const SizedBox(height: 18), Row(children: [const Icon(Icons.auto_awesome, color: Color(0xFFB89BFF), size: 18), const SizedBox(width: 7), Text('AI CLIPPER  •  by RAPIUZY', style: TextStyle(color: Colors.white.withOpacity(.85), fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.2))])
      ]),
      const SizedBox(height: 22), const SectionTitle(number: '01', title: 'Pilih video'), const SizedBox(height: 10),
      InkWell(onTap: pickVideo, borderRadius: BorderRadius.circular(20), child: Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20), border: Border.all(color: videoPath == null ? const Color(0xFF34384C) : cyan)), child: Row(children: [Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0x222E7BFF), borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.video_library_rounded, color: cyan, size: 27)), const SizedBox(width: 14), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(videoName ?? 'Pilih video dari galeri', style: const TextStyle(fontWeight: FontWeight.w800), maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 5), Text(videoPath == null ? 'MP4, MOV, atau video yang didukung' : 'Video dipilih • ketuk untuk mengganti', style: const TextStyle(color: Colors.white60, fontSize: 12))])), const Icon(Icons.add_circle_outline, color: Colors.white70)]))),
      const SizedBox(height: 22), const SectionTitle(number: '02', title: 'Rasio video'), const SizedBox(height: 10), const RatioSelector(),
      const SizedBox(height: 22), const SectionTitle(number: '03', title: 'Gaya subtitle'), const SizedBox(height: 10), const SubtitleSelector(),
      const SizedBox(height: 22), const SectionTitle(number: '04', title: 'Backsound'), const SizedBox(height: 10), const SoundSelector(),
      const SizedBox(height: 24), FilledButton.icon(style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56), backgroundColor: purple, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: busy ? null : () { if (videoPath == null) { showMsg('Pilih video dulu sebelum lanjut.'); return; } Navigator.of(context).push(MaterialPageRoute(builder: (_) => SetupSummary(videoName: videoName ?? 'Video', videoPath: videoPath!))); }, icon: const Icon(Icons.auto_awesome), label: const Text('Lanjut Siapkan Klip', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
      const SizedBox(height: 12), const Center(child: Text('RAPIUZY AI CLIPPER  •  Made with ♥ by RAPIUZY', style: TextStyle(color: Colors.white38, fontSize: 10))),
    ])),
  ));
}

class SectionTitle extends StatelessWidget { final String number; final String title; const SectionTitle({super.key, required this.number, required this.title}); @override Widget build(BuildContext context) => Row(children: [Text(number, style: const TextStyle(color: cyan, fontSize: 12, fontWeight: FontWeight.w900)), const SizedBox(width: 10), Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))]); }

class RatioSelector extends StatefulWidget { const RatioSelector({super.key}); @override State<RatioSelector> createState() => _RatioSelectorState(); }
class _RatioSelectorState extends State<RatioSelector> { int selected = 0; final ratios = const [('9:16', Icons.smartphone_rounded, 'TikTok / Reels'), ('16:9', Icons.crop_16_9_rounded, 'YouTube'), ('1:1', Icons.crop_square_rounded, 'Square')]; @override Widget build(BuildContext context) => Row(children: List.generate(ratios.length, (i) { final r = ratios[i]; final active = selected == i; return Expanded(child: Padding(padding: EdgeInsets.only(right: i == 2 ? 0 : 9), child: InkWell(onTap: () => setState(() => selected = i), borderRadius: BorderRadius.circular(16), child: AnimatedContainer(duration: const Duration(milliseconds: 180), padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 4), decoration: BoxDecoration(color: active ? const Color(0xFF2B1C39) : panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: active ? const Color(0xFFFF8747) : const Color(0xFF303343), width: active ? 1.5 : 1)), child: Column(children: [Icon(r.$2, color: active ? const Color(0xFFFF8747) : Colors.white54, size: 25), const SizedBox(height: 8), Text(r.$1, style: TextStyle(fontWeight: FontWeight.w900, color: active ? const Color(0xFFFFA16D) : Colors.white)), const SizedBox(height: 3), Text(r.$3, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, color: Colors.white54))]))))); })); } }

class SubtitleSelector extends StatefulWidget { const SubtitleSelector({super.key}); @override State<SubtitleSelector> createState() => _SubtitleSelectorState(); }
class _SubtitleSelectorState extends State<SubtitleSelector> { int selected = 0; final styles = const [('Bold Putih', 'Putih tebal + outline hitam', Colors.white), ('Kuning Stroke', 'Kuning terang, outline hitam', Color(0xFFFFE500)), ('Neon Hijau', 'Hijau terang untuk highlight', Color(0xFF4DFF6A)), ('Karaoke Oranye', 'Highlight kata berwarna oranye', Color(0xFFFF8A38)), ('Pop Kata', 'Kata penting lebih menonjol', Color(0xFF55D8FF)), ('Karaoke Hijau', 'Highlight kata hijau neon', Color(0xFF4DFF6A))]; @override Widget build(BuildContext context) => GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: styles.length, gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 9, crossAxisSpacing: 9, childAspectRatio: 1.55), itemBuilder: (_, i) { final s = styles[i]; final active = i == selected; return InkWell(onTap: () => setState(() => selected = i), borderRadius: BorderRadius.circular(16), child: Container(padding: const EdgeInsets.all(13), decoration: BoxDecoration(color: active ? const Color(0xFF2B1C22) : panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: active ? const Color(0xFFFF8747) : const Color(0xFF343744), width: active ? 1.5 : 1)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Aa', style: TextStyle(color: s.$3, fontSize: 23, fontWeight: FontWeight.w900, shadows: const [Shadow(color: Colors.black, blurRadius: 2)])), const SizedBox(height: 5), Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)), const SizedBox(height: 3), Expanded(child: Text(s.$2, style: const TextStyle(color: Colors.white54, fontSize: 10), maxLines: 2, overflow: TextOverflow.ellipsis)), if (active) const Align(alignment: Alignment.bottomRight, child: Icon(Icons.check_circle, color: Color(0xFFFF8747), size: 17))]))); }); } }

class SoundSelector extends StatefulWidget { const SoundSelector({super.key}); @override State<SoundSelector> createState() => _SoundSelectorState(); }
class _SoundSelectorState extends State<SoundSelector> { String value = 'Tidak ada'; @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 15), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(15), border: Border.all(color: const Color(0xFF303343))), child: DropdownButtonHideUnderline(child: DropdownButton<String>(value: value, isExpanded: true, dropdownColor: panel, items: const ['Tidak ada', 'Enerjik', 'Santai', 'Cinematic', 'Upload musik sendiri'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) { if (v != null) setState(() => value = v); }))); }

class SetupSummary extends StatefulWidget { final String videoName; final String videoPath; const SetupSummary({super.key, required this.videoName, required this.videoPath}); @override State<SetupSummary> createState() => _SetupSummaryState(); }
class _SetupSummaryState extends State<SetupSummary> { VideoPlayerController? controller; bool previewError = false; @override void initState() { super.initState(); _initPreview(); } Future<void> _initPreview() async { try { final c = VideoPlayerController.file(File(widget.videoPath)); await c.initialize(); if (!mounted) { c.dispose(); return; } setState(() => controller = c); } catch (_) { if (mounted) setState(() => previewError = true); } } @override void dispose() { controller?.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Detail Video', style: TextStyle(fontWeight: FontWeight.w800)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Ganti'))]), body: SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('VIDEO DIPILIH', style: TextStyle(color: cyan, fontSize: 10, letterSpacing: 1.5, fontWeight: FontWeight.w800)), const SizedBox(height: 7), Text(widget.videoName, style: const TextStyle(fontWeight: FontWeight.w800), maxLines: 2, overflow: TextOverflow.ellipsis), const SizedBox(height: 14), if (controller != null && controller!.value.isInitialized) AspectRatio(aspectRatio: controller!.value.aspectRatio, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: Stack(alignment: Alignment.center, children: [VideoPlayer(controller!), IconButton.filled(onPressed: () { setState(() { controller!.value.isPlaying ? controller!.pause() : controller!.play(); }); }, icon: Icon(controller!.value.isPlaying ? Icons.pause : Icons.play_arrow, size: 32))]))) else Container(height: 180, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(12)), child: Center(child: Icon(previewError ? Icons.video_file_outlined : Icons.hourglass_top_rounded, size: 42, color: cyan))),])), const SizedBox(height: 18), Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF211B31), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFF554081))), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Icon(Icons.info_outline, color: Color(0xFFC5A8FF)), SizedBox(width: 8), Text('Status pemrosesan', style: TextStyle(fontWeight: FontWeight.w800))]), SizedBox(height: 8), Text('Tampilan Clipper dan pemilihan video sudah disiapkan. Untuk mendeteksi momen viral, membuat klip otomatis, membakar subtitle ke video, dan mengekspor hasil ke galeri, aplikasi perlu dihubungkan ke backend AI/video processing.', style: TextStyle(color: Colors.white70, height: 1.45, fontSize: 13))])), const SizedBox(height: 18), FilledButton.icon(onPressed: () => showDialog(context: context, builder: (ctx) => AlertDialog(backgroundColor: panel, title: const Text('Backend AI belum terhubung'), content: const Text('Aplikasi ini saat ini menyiapkan alur Clipper dan preview video. Pemrosesan klip otomatis belum aktif karena URL/API backend Clipper belum tersedia.'), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Mengerti'))])), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(54), backgroundColor: purple, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))), icon: const Icon(Icons.auto_awesome), label: const Text('Buat Klip AI', style: TextStyle(fontWeight: FontWeight.w800))), const SizedBox(height: 10), OutlinedButton.icon(onPressed: () => Navigator.pop(context), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), side: const BorderSide(color: Color(0xFF45485C)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))), icon: const Icon(Icons.arrow_back), label: const Text('Kembali ke Studio'))])));
}
